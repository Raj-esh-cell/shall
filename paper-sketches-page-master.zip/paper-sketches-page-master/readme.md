# Paper *Sketches* Page

This is the Sketches page of Paper pulled out into its own repository for Paper
to load it dynamically.

## Running

Go to Paper > Pages and define this page there. The Sketches page will then show
up in the Paper tabs. You can use it through there.

## Testing

There is no support for testing outside of Paper yet, but it is coming.

## To-Do

### Add support for testing outside of Paper
