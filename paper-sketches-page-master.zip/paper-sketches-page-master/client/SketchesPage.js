// TODO: Have these be provided as a client API instead of importing from Paper
import call from '/call.js';
import LinkButton from '/LinkButton.js';
import loadImage from '/loadImage.js';
import serializeBlob from '/serializeBlob.js';
import pickFile from '/pickFile.js';
import Component from '/Component.js';

export default class SketchesPage extends Component {
  constructor() {
    super(SketchesPage);

    this.bind(
      this.handleNewLinkButtonClick,
      this.handleUploadLinkButtonClick,
      this.handleSelectChange,
      this.handleCanvasPointerMove,
    );

    const div = document.createElement('div');

    this._newLinkButton = new LinkButton();
    this._newLinkButton.textContent = '+';
    this._newLinkButton.addEventListener('click', this.handleNewLinkButtonClick);

    this._uploadLinkButton = new LinkButton();
    this._uploadLinkButton.textContent = 'Upload';
    this._uploadLinkButton.addEventListener('click', this.handleUploadLinkButtonClick);

    div.append(this._newLinkButton, this._uploadLinkButton);

    this._select = document.createElement('select');
    this._select.multiple = true;
    this._select.addEventListener('change', this.handleSelectChange);

    // TODO: Handle mouse, touch and pointer (tablet) separately as needed
    this._canvas = document.createElement('canvas');
    this._canvas.addEventListener('pointermove', this.handleCanvasPointerMove);

    this._shadowRoot.append(div, this._select, this._canvas);
    this.load();
  }

  async load() {
    const response = await call('/api/sketches');
    const sketches = await response.json();
    this._select.innerHTML = '';
    for (const sketch of sketches) {
      const option = document.createElement('option');
      option.value = sketch.id;
      option.textContent = sketch.name;
      this._select.append(option);
    }
  }

  async handleNewLinkButtonClick() {
    await call('/api/sketch', { method: 'POST' });
    await this.load();
  }

  async handleUploadLinkButtonClick() {
    const file = await pickFile();
    const url = await serializeBlob(file);
    await call('/api/sketch', { method: 'POST', body: JSON.stringify({ name: file.name, url }) });
    await this.load();
  }

  async handleSelectChange() {
    const response = await call(`/api/sketch?${this._select.value}`);
    const sketch = await response.json();
    this._canvas.dataset.id = sketch.id;
    if (sketch.url) {
      const image = await loadImage(sketch.url);
      this._canvas.width = image.naturalWidth;
      this._canvas.height = image.naturalHeight;
      this._context = this._canvas.getContext('2d');
      this._context.drawImage(image, 0, 0)
    }
    else {
      this._context = this._canvas.getContext('2d');
    }
  }

  async handleCanvasPointerMove(/** @type {PointerEvent} */ event) {
    if (event.buttons !== 1) {
      return;
    }

    this._context.moveTo(event.offsetX, event.offsetY);
    this._context.lineTo(event.offsetX + event.movementX, event.offsetY + event.movementY);
    this._context.stroke();

    const id = Number(event.currentTarget.dataset.id);
    await this.save(id);
  }

  async save(id) {
    if (this._canvas.dataset.saving === 'true') {
      return;
    }

    this._canvas.dataset.saving = true;

    const url = this._canvas.toDataURL();
    await call(`/api/sketch?${id}`, { method: 'PATCH', body: JSON.stringify({ url }) });

    // TODO: Fix the backend for this not to be needed
    await new Promise(resolve => setTimeout(resolve, 1000));

    this._canvas.dataset.saving = false;
    if (this._canvas.toDataURL() === url) {
      return;
    }

    await this.save(id);
  }
}
